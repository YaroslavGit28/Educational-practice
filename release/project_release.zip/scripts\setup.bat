@echo off
chcp 65001 > nul
cd /d "%~dp0\.."
echo ========================================
echo Установка зависимостей проекта
echo ========================================
if not exist .venv (
    python -m venv .venv
)
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
pip install -r requirements-dev.txt
python manage.py migrate
python manage.py load_demo_data
echo.
echo Установка завершена успешно.
pause
