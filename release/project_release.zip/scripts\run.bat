@echo off
chcp 65001 > nul
cd /d "%~dp0\.."
echo ========================================
echo Запуск интернет-магазина
echo ========================================
call .venv\Scripts\activate.bat
python manage.py runserver 0.0.0.0:8000
